

class Connection():
   

    def __init__(self, instance):
        '''
        Constructor
        '''
        