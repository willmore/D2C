'''
Created on Feb 10, 2011

@author: willmore
'''

class AMI:
    
    def __init__(self, amiId, srcImg=None):
        self.amiId = amiId
        self.srcImg = srcImg

