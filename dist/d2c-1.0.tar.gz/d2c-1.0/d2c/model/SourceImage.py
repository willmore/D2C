'''
Created on Feb 10, 2011

@author: willmore
'''

class SourceImage(object):
    '''
    classdocs
    '''
        
    def __init__(self, path):
        '''
        Constructor
        '''
        self.path = path
        