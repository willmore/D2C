class SSHCred:
    
    def __init__(self, username, privateKey):
        self.username = username
        self.privateKey = privateKey