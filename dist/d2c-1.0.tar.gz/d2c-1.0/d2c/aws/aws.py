'''
Created on Feb 14, 2011

@author: willmore
'''

class AWS:
    
    def __init__(self, aws_cred, ec2_cred):
        self._aws_cred = aws_cred
        self._ec2_cred = ec2_cred
        
    def ec2_bundle_image(self):
        #TODO
        return None
        
    def ec2_upload_bundle(self):
        #TODO
        return None
        
    def ec2_register(self):
        #TODO
        return None
    